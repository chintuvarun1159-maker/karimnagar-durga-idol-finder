# 🕉️ Ganesh Darshan Jagtial - Full Website & Admin Panel

A modern, responsive web application inspired by `findjagtialganesh.site`, built with an **Admin Panel** to edit all texts, stats, images, categories, areas, and mandapam listings displayed on the index page.

---

## 🚀 Quick Start (Zero Setup Required)

You can run this website in two simple ways:

### Option 1: Direct Browser Access (No Installation Needed)
1. Navigate to `C:\Users\chint\.gemini\antigravity\scratch\ganesh-darshan-app`
2. Double-click **`index.html`** in your file explorer.
3. The site runs with all interactive features, Leaflet GPS maps, and local persistence.

### Option 2: Running with Node.js Server
```bash
cd C:\Users\chint\.gemini\antigravity\scratch\ganesh-darshan-app
npm install
npm start
```
Open **`http://localhost:3000`** in your browser.

---

## ⚙️ How to Use the Admin Panel

1. Click on the **`⚙️ Admin Panel`** button in the top navbar or visit `admin.html` (or click Admin in the mobile menu).
2. Enter the password:
   - **Default Admin Password**: `admin123` (customizable in `admin.js`)
3. The Admin Panel allows you to edit:
   - **Hero Section**: Telugu Chant (`॥ వినాయకాయ నమః ॥`), Main Title, City Highlight, Subtitle, Description, Hero Image URL, Floating Badges.
   - **Live Stats Counters**: Total Locations count, Unique Themes count, Photos count, Live Views count, Sacred Quote.
   - **Mandapams Directory**: Add new mandapams, edit existing mandapams, delete, reorder priority (#1, #2, #3...), toggle "Must Visit" status, upload/link photo URLs, video reels, and Instagram links.
   - **Areas Manager**: Add or remove Jagtial neighbourhood areas (Krishna Nagar, Vani Nagar, Market Area, Aravind Nagar, etc.).
   - **CTA Banner & Footer**: Title, description, developer credits, copyright text.
   - **Backup & Restore**: Download all site data as a JSON file or import a saved backup.

---

## 🌟 Key Features Included

- 🕉️ **Festive Indian Saffron & Gold Theme**: Styled with Telugu typography, festive gradients, glassmorphism, and responsive design.
- 🗺️ **Interactive Leaflet GPS Map**: Saffron Ganesha pins across Jagtial with turn-by-turn driving directions in Google Maps.
- 📍 **"Use My Location" Distance Finder**: Detects user coordinates and sorts all Ganesh idols by nearest proximity (km).
- 🏆 **"Must Visit Places" Priority Carousel**: Auto-scrolling horizontal rail with ranks (#1, #2, #3...), reel counters, and IG handles.
- ✨ **"Unique Ganesh Idols" Showcase**: Displays creative theme idols (Eco-Friendly Clay, Tallest, Traditional, Creative).
- 📸 **Moments Gallery**: Darshan photos and celebration reels.
- 🔍 **Live Instant Search & Category Filters**: Search by name, Telugu name, area, or keywords in real-time.
- 💬 **WhatsApp Darshan Share**: Share direct mandapam details and Google Map routes to WhatsApp groups.
- ➕ **Community "Add Ganesh" Submission**: Form allowing devotees and youth committees to submit their idols.

---

## 📂 Project Structure

```
ganesh-darshan-app/
├── index.html        # Main Homepage with interactive sections & integrated admin
├── admin.html        # Standalone Admin Panel page
├── styles.css        # Festive saffron/gold CSS, glassmorphism, and animations
├── data.js           # Default Jagtial mandapams data, site settings, and storage handlers
├── app.js            # Frontend reactive engine, GPS distance calculator, Leaflet maps
├── admin.js          # Admin dashboard controller, CRUD handlers, backup exporter
├── server.js         # Express server with REST endpoints
└── package.json      # Dependencies and scripts
```

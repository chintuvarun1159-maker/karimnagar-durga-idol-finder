@echo off
title Karimnagar Durga Idol Finder
echo ========================================================
echo   Launching Karimnagar Durga Idol Finder...
echo ========================================================
start "" "http://localhost:3000"
node server.js
pause
